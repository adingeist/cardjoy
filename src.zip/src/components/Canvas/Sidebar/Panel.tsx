import { Typography } from '@mui/material';
import React from 'react';
import styled from 'styled-components';

const StyledPanel = styled.div`
  width: 300px;
  background-color: ${({ theme }) => theme.palette.primary.light};
`;

type Props = {
  activeTab: string | null;
};

const Panel: React.FC<Props> = ({ activeTab }) => {
  return (
    <StyledPanel>
      <Typography variant="h6" component="div">
        The {activeTab} panel is active!
      </Typography>
    </StyledPanel>
  );
};

export default Panel;
