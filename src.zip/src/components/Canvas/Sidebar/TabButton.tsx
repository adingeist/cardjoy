import React from 'react';
import styled from 'styled-components';
import { ListItem, ListItemIcon, ListItemText } from '@mui/material';

interface TabButtonProps {
  isActive: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}

const StyledTabButton = styled(ListItem)<{ isActive: boolean }>`
  background-color: ${({ isActive, theme }) =>
    isActive ? theme.palette.primary.dark : 'transparent'};
  color: ${({ isActive }) => (isActive ? 'white' : 'inherit')};
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  &:hover {
    background-color: ${({ theme }) => theme.palette.primary.dark};
  }
`;

const StyledListItemIcon = styled(ListItemIcon)`
  display: flex;
  align-items: center;
  justify-content: center;
`;

const TabButton: React.FC<TabButtonProps> = ({
  isActive,
  onClick,
  icon,
  label,
}) => {
  return (
    <StyledTabButton isActive={isActive} onClick={onClick}>
      <StyledListItemIcon sx={{ color: 'white' }}>{icon}</StyledListItemIcon>
      <ListItemText primary={label} />
    </StyledTabButton>
  );
};

export default TabButton;
