import {
  AutoAwesome,
  EmojiNature,
  Image,
  Interests,
  Title,
} from '@mui/icons-material';
import { List } from '@mui/material';
import React, { useState } from 'react';
import styled from 'styled-components';
import Panel from './Panel';
import TabButton from './TabButton';

interface SidebarProps {}

const Sidebar = styled.div`
  width: 100px;
  background-color: ${({ theme }) => theme.palette.primary.main};
  color: white;
  display: flex;
  flex-direction: column;
`;

const CanvasSidebar: React.FC<SidebarProps> = () => {
  const [activeTab, setActiveTab] = useState<string | null>(null);

  const handleTabClick = (tab: string) => {
    setActiveTab(tab);
  };

  return (
    <>
      <Sidebar>
        <List>
          <TabButton
            icon={<Interests />} // Material-UI icon for Shapes
            label="Shapes"
            isActive={false}
            onClick={function (): void {
              handleTabClick('Shapes');
            }}
          />
          <TabButton
            icon={<EmojiNature />} // Material-UI icon for Graphics
            label="Graphics"
            isActive={false}
            onClick={() => handleTabClick('Graphics')}
          />
          <TabButton
            icon={<Title />} // Material-UI icon for Text
            label="Text"
            isActive={false}
            onClick={() => handleTabClick('Text')}
          />
          <TabButton
            icon={<AutoAwesome />} // Material-UI icon for Text
            label="Generate"
            isActive={false}
            onClick={() => handleTabClick('Text')}
          />
          <TabButton
            icon={<Image />} // Material-UI icon for Text
            label="Uploads"
            isActive={false}
            onClick={() => handleTabClick('Text')}
          />
        </List>
      </Sidebar>
      <Panel activeTab={activeTab} />
    </>
  );
};

export default CanvasSidebar;
